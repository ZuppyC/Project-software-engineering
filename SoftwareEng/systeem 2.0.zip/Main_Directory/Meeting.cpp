    //
// Created by Dell on 26/02/2026.
//

#include "Meeting.h"
#include <iostream>
#include <ctime>
#include <fstream>
#include <bits/locale_classes.h>
#include "../src/DesignByContract.h"

Meeting::Meeting() {
    _initCheck = this;
}

bool Meeting::properlyInitialized() {
    return _initCheck == this;
}

bool Meeting::getCo2Tracked() {
    REQUIRE(properlyInitialized(), "MEETING is niet geinitialiseerd");
    return co2Tracked;
}

void Meeting::setCo2Tracked(bool tracked) {
    REQUIRE(properlyInitialized(), "MEETING is niet geinitialiseerd");
    co2Tracked = tracked;
    ENSURE(co2Tracked==true||co2Tracked==false, "CO2tracking is niet goed gelezen.");
}

void Meeting::setId(string id) {
    REQUIRE(properlyInitialized(), "MEETING is niet geinitialiseerd");
    REQUIRE(!id.empty(), "Er is geen MEETING");
    this->identifier = id;
    ENSURE(this->identifier==id, "MEETING is niet gelezen");
}
string Meeting::getId() {
    REQUIRE(properlyInitialized(), "MEETING is niet geinitialiseerd");
    return identifier;
}

void Meeting::setLabel(string label) {
    REQUIRE(properlyInitialized(), "MEETING is niet geinitialiseerd");
    REQUIRE(!label.empty(), "Er is geen LABEL");

    this->label = label;
    ENSURE(this->label==label, "LABEL is niet gelezen");
}
string Meeting::getLabel() {
    REQUIRE(properlyInitialized(), "MEETING is niet geinitialiseerd");
    return label;
}

void Meeting::setRoom(string roomnr) {
    REQUIRE(properlyInitialized(), "MEETING is niet geinitialiseerd");
    REQUIRE(!roomnr.empty(), "Er is geen ROOM");
    this->room = roomnr;
    ENSURE(this->room==roomnr, "ROOM is niet gelezen");
}
string Meeting::getRoom() {
    REQUIRE(properlyInitialized(), "MEETING is niet geinitialiseerd");
    return room;
}

void Meeting::setDate(const string& a) {
    REQUIRE(properlyInitialized(), "MEETING is niet geinitialiseerd");
    REQUIRE(a.size() == 10 && a[4]=='-' && a[7]=='-', "DATE moet formaat YYYY-MM-DD zijn");
    date = strToTm(a);
    ENSURE(date != nullptr, "DATE is niet gelezen");
}
tm* Meeting::getDate() const {

    return date;
}

tm* Meeting::strToTm(const string& datum) {
    REQUIRE(properlyInitialized(), "MEETING is niet geinitialiseerd");
    REQUIRE(datum.size() == 10 && datum[4]=='-' && datum[7]=='-', "DATE moet formaat YYYY-MM-DD zijn");
    int jaar = stoi(datum.substr(0, 4));

    int maand= stoi(datum.substr(5, 2));

    int dag = stoi(datum.substr(8, 2));

    tm* time= new tm();
    time->tm_mday= dag;
    time->tm_mon= maand - 1;
    time->tm_year= jaar - 1900;

    vector<int> maand1= {1,3,5,7,8,10,12};
    bool dertig = true;
    for (int i: maand1) {
        if (i==maand) {
            dertig= false;
        }
    }

    ENSURE(maand<13, "De maand kan niet hoger zijn dan 12");
    ENSURE(maand>0, "De maand kan niet kleiner zijn dan 1");
    ENSURE(dag>0,"De dag kan niet kleiner zijn dan 1");
    ENSURE((dag<30 && dertig) || (dag<31 && !dertig), "De dag kan niet groter zijn dan 30 of 31");

    return time;
}

void Meeting::setPart(Participation* part) {
    REQUIRE(properlyInitialized(), "MEETING is niet geinitialiseerd");
    REQUIRE(part != nullptr, "Er is geen PARTICIPATION");
    participants.push_back(part);
    bool part_in_p= false;
    for (Participation* part_ :participants) {
        if (part==part_) {
            part_in_p= true;
        }
    }
    ENSURE(part_in_p, "PARTICIPATION is niet gelezen");
}

vector<Participation*> Meeting::getPart() const {

    return participants;
}


bool Meeting::isPast() {
    REQUIRE(properlyInitialized(), "MEETING is niet geinitialiseerd");
    time_t t = time(nullptr);
    tm* today = localtime(&t);

    tm* mdate = date;
    bool a = today->tm_year > mdate->tm_year;
    bool b= today->tm_year == mdate->tm_year && today->tm_mon > mdate->tm_mon;
    bool c= today->tm_year == mdate->tm_year && today->tm_mon == mdate->tm_mon && today->tm_mday > mdate->tm_mday;
    return a||b||c;
}

bool Meeting::conflictsWith(Meeting* m) {
    REQUIRE(properlyInitialized(), "MEETING is niet geinitialiseerd");
    REQUIRE(m != nullptr, "Er is geen MEETING");
    tm* d1 = this->date;
    tm* d2 = m->getDate();

    if (d1->tm_mday == d2->tm_mday && d1->tm_mon == d2->tm_mon && d1->tm_year == d2->tm_year
        && room== m->getRoom() && hour== m->getHour()){
        return true;

    }
    return false;
}

bool Meeting::getBezig() {
    REQUIRE(properlyInitialized(), "MEETING is niet geinitialiseerd");
    return isBezig;
}

void Meeting::setBezig(bool bezig) {
    REQUIRE(properlyInitialized(), "MEETING is niet geinitialiseerd");
    isBezig= bezig;
    ENSURE(isBezig==bezig, "isBezig variabele niet goed ingesteld");
}

void Meeting::setCanceled(bool canceled) {
    REQUIRE(properlyInitialized(), "MEETING is niet geinitialiseerd");
    isCanceled= canceled;
    ENSURE(isCanceled==canceled, "IsCanceled variabele niet goed ingesteld");
}

bool Meeting::getCanceled() {
    REQUIRE(properlyInitialized(), "MEETING is niet geinitialiseerd");
    return isCanceled;
}

bool Meeting::getOnline() {
    REQUIRE(properlyInitialized(), "MEETING is niet geinitialiseerd");
    return isOnline;
}

void Meeting::setOnline(bool online) {
    REQUIRE(properlyInitialized(), "MEETING is niet geinitialiseerd");
    isOnline= online;
}

bool Meeting::getCatering() {
    REQUIRE(properlyInitialized(), "MEETING is niet geinitialiseerd");
    return hasCatering;
}
void Meeting::setCatering(string catering) {
    REQUIRE(properlyInitialized(), "MEETING is niet geinitialiseerd");
    REQUIRE(catering=="true"||catering=="false", "De CATERING variabele mag alleen 'true' of 'false' zijn.");
    if (catering=="true") {
        hasCatering= true;
    }
    else {
        hasCatering= false;
    }
    ENSURE(hasCatering==true && catering=="true"||hasCatering==false && catering=="false", "De EXTERNALS variabele is niet juist gelezen.");

}

bool Meeting::getExternals() {
    REQUIRE(properlyInitialized(), "MEETING is niet geinitialiseerd");
    return hasExternals;
}

void Meeting::setExternals(string externals) {
    REQUIRE(properlyInitialized(), "MEETING is niet geinitialiseerd");
    REQUIRE(externals=="true"||externals=="false", "De EXTERNALS variabele mag alleen 'true' of 'false' zijn.");
    if (externals=="true") {
        hasExternals= true;
    }
    else {
        hasExternals= false;
    }
    ENSURE(hasExternals==true && externals=="true"||hasExternals==false && externals=="false", "De EXTERNALS variabele is niet juist gelezen.");

}

int Meeting::getHour() {
    REQUIRE(properlyInitialized(), "MEETING is niet geinitialiseerd");
    return hour;
}

void Meeting::setHour(int h) {
    REQUIRE(properlyInitialized(), "MEETING is niet geinitialiseerd");
    REQUIRE(h >= 0 && h <= 23, "Hour moet tusssen 0 en 23 zijn ");
    hour = h;
    ENSURE(hour == h, "Hour is niet correct gezet");
}

void Meeting::setOccupancy(int occupancy_) {
    REQUIRE(properlyInitialized(), "MEETING is niet geinitialiseerd");
    REQUIRE(occupancy_>1, "Er moeten 2 or meer mensen in de ROOM kunnen");
    this->occupancy = occupancy_;
    ENSURE(occupancy==occupancy_, "OCCUPANCY is niet goed ingesteld");
}

int Meeting::getOccupancy() {
    REQUIRE(properlyInitialized(), "MEETING is niet geinitialiseerd");
    return occupancy;
}

void Meeting::printMeeting(ofstream& outputfile) {
    REQUIRE(properlyInitialized(), "MEETING is niet geinitialiseerd");
    outputfile<<"["<<label<<"]"<<endl;
    tm* d1 = date;
    outputfile<<" -  ID:  "<<identifier<<endl;
    outputfile<<" -  Time:  "<<d1->tm_mday<<"/"<<d1->tm_mon + 1<<"/"<<d1->tm_year + 1900<<", "<<hour<<"h00"<<endl;
    outputfile<<" -  Location:  "<<room<<endl;
    if (hasExternals) {
        outputfile<<" -  Externals allowed"<<endl;
    }
    else {
        outputfile<<" -  Externals not allowed"<<endl;
    }
    if (hasCatering) {
        outputfile<<" -  Catering"<<endl;
    }
    else {
        outputfile<<" -  No Catering"<<endl;
    }

}
double Meeting::co2ZonderCatering() {
    REQUIRE(properlyInitialized(), "MEETING is niet geinitialiseerd");

    if (isOnline) {
        return participants.size()*30;
    }
    double aantalCO2=0.0;

    for (Participation* p : participants) {
        if (p->getExternal()) {
            aantalCO2+=1200;
        }
        else {
            aantalCO2+=120;
        }
    }
    return aantalCO2;
}

Meeting::~Meeting()
{

}

